
export default function Home() {
  return (
    <main style={{ padding: 40 }}>
      <h1>Gas Tech Match</h1>
      <p>Marketplace for certified commercial gas technicians.</p>
    </main>
  );
}
