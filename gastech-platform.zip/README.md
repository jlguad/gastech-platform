
# GasTech Platform

Marketplace platform connecting certified commercial gas technicians
with warranty work from commercial kitchen equipment brands.

## Structure
- /app     -> Frontend (Next.js)
- /server  -> Backend (Express API)
